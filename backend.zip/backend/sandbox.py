# from app.models.election_tables import people, electoral_roll, candidate_list, bulletin_board

# from app.helios_crypto import algs
from Crypto.Hash import SHA256
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
import base64
import traceback

PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
ME4wEAYHKoZIzj0CAQYFK4EEACEDOgAEldOO+DZ95yenqbH1WpkLYylYUEbp51zV
2aKUlw1jMCLY4s8EH30hgUDO6XG+S9+42mFgDR0qZ/U=
-----END PUBLIC KEY-----"""

SIGNATURE = "MD0CHQDm4V8xbAdeWPSvAoaD1ot5Ox+DoE402vfEPy6EAhxJlYsIxoD/uXLeLhxNofzuWdx/6xbpK3LKSExn"


def main():
    try:
        # tmpkey = ECC.generate(curve='secp224r1')
        # print(repr(tmpkey.export_key(format='PEM')))
        message = b'alice'
        # print(repr(PUBLIC_KEY_PEM))  # 公開鍵の中身を確認

        public_key = ECC.import_key(PUBLIC_KEY_PEM, curve_name='secp224r1')
        hash_value = SHA256.new(message)
        dec_signature = base64.b64decode(SIGNATURE)
        print(f"Decoded signature length: {len(dec_signature)}")
        verifier = DSS.new(public_key, "fips-186-3")
        verifier.verify(hash_value, dec_signature)
        print("Signature is valid.")

    except ValueError as e:
        print("value error", e)
        # traceback.print_exc()
    except Exception as e:
        print("Error", e)

if __name__ == '__main__':
    main()