class Ballot(object):

class Voter(object):