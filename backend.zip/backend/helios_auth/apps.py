from django.apps import AppConfig

class HeliosAuthConfig(AppConfig):
    name = 'helios_auth'
    verbose_name = "Helios Authentication"
